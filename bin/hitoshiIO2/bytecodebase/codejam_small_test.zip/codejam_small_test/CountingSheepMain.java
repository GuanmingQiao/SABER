package p7;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Stack;

public class CountingSheepMain {

	static final String IN_FILE = "A-large.in";
//	static final String IN_FILE = "D:\\C-large-practice.in";
//	static final String IN_FILE = "D:\\D-large-practice.in";
//	static final String IN_FILE = "D:\\A-small-attempt0.in";
//	static final String IN_FILE = "D:\\codejam_in.txt";
	static final String OUT_FILE = "D:\\codejam_out.txt";
	static FileReader inFile = null;
	static FileWriter outFile = null;
	static BufferedReader in = null;
	static BufferedWriter out = null;
	static boolean firstLine = true;

	public static void main(String[] args) {
		// Open input and output file
		try {
			openIn();
			openOut();

			// Run the solution
			solution();
		} catch (IOException e) {
			e.printStackTrace();
		}

		// Close intput and output file
		closeInAndOut();
	}

	/**
	* Solution of a codejam problem
	* @throws IOException
	*/
	static void solution() throws IOException {
		// Number of cases
		int cases = Integer.parseInt(in.readLine().trim());
		for (int t = 1; t <= cases; t++) {
			long n = Long.parseLong(in.readLine().trim());
			boolean[] encounteredDigits = new boolean[10];
			Arrays.fill(encounteredDigits, false);
			String answer = "INSOMNIA";
			
			if (n > 0) {
				for (int i = 1; i < 100000; i++) {
					String product = Long.toString(n * i);
					for (char c : product.toCharArray()) encounteredDigits[c - '0'] = true;
					if (isComplete(encounteredDigits)) {
						answer = product;
						break;
					}
				}
			}
			
			writeAndPrint(String.format("Case #%s: %s", t, answer));
			firstLine = false;
		}
	}
	
	// Checks if all digits have been encountered
	static boolean isComplete(boolean[] digits) {
		for (boolean b : digits) if (!b) return false;
		return true;
	}
	
	/*
	 * Utility methods	
	 */
	
	/**
	* @param str  Line containing multiple integer values
	* @return     Stack containing parsed Integer values in FILO order
	*/
	static Stack<Integer> getInts(String str) {
		Stack<Integer> ls = new Stack<Integer>();
		for (String s : str.split(" ")) ls.push(Integer.parseInt(s));
		return ls;
	}
     
	/**
	* @param str  Line containing multiple Long values
	* @return     Stack containing parsed Long values in FILO order
	*/
	static Stack<Long> getLongs(String str) {
		Stack<Long> ls = new Stack<Long>();
		for (String s : str.split(" ")) ls.push(Long.parseLong(s));
		return ls;
	}
     
	/**
	* Writes simultaneously to output file and console
	* @param str
	* @throws IOException
	*/
	static void writeAndPrint(String str) throws IOException {
		if (!firstLine) out.newLine();
		System.out.println(str);
		out.write(str);
	}
     
	/**
	* Opens the predefined input file
	* @throws FileNotFoundException
	*/
	static void openIn() throws FileNotFoundException {
		inFile = new FileReader(IN_FILE);
		in = new BufferedReader(inFile);
	}
 
	/**
	* Opens an output file
	* @throws IOException
	*/
	static void openOut() throws IOException {
		outFile = new FileWriter(OUT_FILE);
		out = new BufferedWriter(outFile);
	}
     
	/**
	* Close input and output file and corresponding reader/writer
	*/
	static void closeInAndOut() {
		if (out != null) {
			try {out.close();}
			catch (IOException e) {}
		}
		if (outFile != null) {
			try {out.close();}
			catch (IOException e) {}
		}
		if (in != null) {
			try {out.close();}
			catch (IOException e) {}
		}
		if (inFile != null) {
			try {out.close();}
			catch (IOException e) {}
		}
	}
	
	/**
	 * Convenient formated print
	 */
	static void fPrint(String fmt, Object... args) {System.out.println(String.format(fmt, args));}
}
