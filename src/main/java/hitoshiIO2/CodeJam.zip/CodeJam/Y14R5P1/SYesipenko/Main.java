package CodeJam.Y14R5P1.SYesipenko;

import java.io.*;
import java.util.*;
import static java.lang.Math.*;
import static java.util.Arrays.fill;
import static java.util.Arrays.binarySearch;
import static java.util.Arrays.sort;

public class Main {
	public static void main(String[] args) throws IOException {
		long prevTime = System.currentTimeMillis();
		new Main().run();
		System.out.println("Total time: " + (System.currentTimeMillis() - prevTime) + " ms");
		System.out.println("Memory status: " + memoryStatus());
	}

//	String inputFile = "sample.txt";
//	String inputFile = "input/A-small-attempt0.in";
	String inputFile = System.getenv("TEST_FILES_HOME") + "test_files/Y14R5P1/A.in";
	
	String outputFile = System.getenv("TEST_FILES_HOME") + "test_files/Y14R5P1/A.out";
	
	void run() throws IOException {
		in = new BufferedReader(new FileReader(inputFile));
		out = new PrintWriter(outputFile);
		solve();
		out.close();
	}
	
	
	void solve() throws IOException {
		for (int testCase = 1, testCases = nextInt(); testCase <= testCases; testCase++) {
			System.out.println("Case #" + testCase + ": ");
			solve(testCase);
		}
	}

	static final int OFFSET = 20;
	
	void solve(int testCase) throws IOException {
		out.print("Case #" + testCase + ": ");
		
		final int N = nextInt();
		final long p = nextInt();
		final long q = nextInt();
		final long r = nextInt();
		final long s = nextInt();
		
		final long[] counts = new long [N];
		for (int i = 0; i < N; i++)
			counts[i] = (i * p + q) % r + s;
		final long[] sums = new long [N + 1];
		for (int i = 0; i < N; i++)
			sums[i + 1] = sums[i] + counts[i];
		final long total = sums[N];
		
		long answer = 0L;
		
		for (int start = 0; start < N; start++) {
			final long leftCount = sums[start];
			
			int left = start;
			int right = N;
			
			while (left <= right) {
				final int middle = (left + right) >> 1;
				final long midCount = sums[middle] - sums[start];
				final long rightCount = sums[N] - sums[middle];
				if (midCount < rightCount) {
					left = middle + 1;
				} else {
					right = middle - 1;
				}
			}
			
			long minSolveig = Long.MAX_VALUE;
			for (int boundary = max(start, left - OFFSET); boundary <= min(N, left + OFFSET); boundary++) {
				final long midCount = sums[boundary] - sums[start];
				final long rightCount = sums[N] - sums[boundary];
				minSolveig = min(minSolveig, max(leftCount, max(midCount, rightCount)));
			}
			answer = max(answer, total - minSolveig);
		}
		out.printf(Locale.US, "%.10f%n", answer / (double) total);
	}
	
	
	/*************************************************************** 
	 * Input 
	 **************************************************************/
	
	BufferedReader in;
	PrintWriter out;
	StringTokenizer st = new StringTokenizer("");
	
	String nextToken() throws IOException {
		while (!st.hasMoreTokens())
			st = new StringTokenizer(in.readLine());
		return st.nextToken();
	}
	
	int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}
	
	long nextLong() throws IOException {
		return Long.parseLong(nextToken());
	}
	
	double nextDouble() throws IOException {
		return Double.parseDouble(nextToken());
	}
	
	int[] nextIntArray(int size) throws IOException {
		int[] ret = new int [size];
		for (int i = 0; i < size; i++)
			ret[i] = nextInt();
		return ret;
	}
	
	long[] nextLongArray(int size) throws IOException {
		long[] ret = new long [size];
		for (int i = 0; i < size; i++)
			ret[i] = nextLong();
		return ret;
	}
	
	double[] nextDoubleArray(int size) throws IOException {
		double[] ret = new double [size];
		for (int i = 0; i < size; i++)
			ret[i] = nextDouble();
		return ret;
	}
	
	String nextLine() throws IOException {
		st = new StringTokenizer("");
		return in.readLine();
	}
	
	boolean EOF() throws IOException {
		while (!st.hasMoreTokens()) {
			String s = in.readLine();
			if (s == null)
				return true;
			st = new StringTokenizer(s);
		}
		return false;
	}
	
	/*************************************************************** 
	 * Output 
	 **************************************************************/
	void printRepeat(String s, int count) {
		for (int i = 0; i < count; i++)
			out.print(s);
	}
	
	void printArray(int[] array) {
		if (array == null || array.length == 0)
			return;
		for (int i = 0; i < array.length; i++) {
			if (i > 0) out.print(' ');
			out.print(array[i]);
		}
		out.println();
	}
	
	void printArray(long[] array) {
		if (array == null || array.length == 0)
			return;
		for (int i = 0; i < array.length; i++) {
			if (i > 0) out.print(' ');
			out.print(array[i]);
		}
		out.println();
	}
	
	void printArray(double[] array) {
		if (array == null || array.length == 0)
			return;
		for (int i = 0; i < array.length; i++) {
			if (i > 0) out.print(' ');
			out.print(array[i]);
		}
		out.println();
	}
	
	void printArray(double[] array, String spec) {
		if (array == null || array.length == 0)
			return;
		for (int i = 0; i < array.length; i++) {
			if (i > 0) out.print(' ');
			out.printf(Locale.US, spec, array[i]);
		}
		out.println();
	}
	
	void printArray(Object[] array) {
		if (array == null || array.length == 0)
			return;
		boolean blank = false;
		for (Object x : array) {
			if (blank) out.print(' '); else blank = true;
			out.print(x);
		}
		out.println();
	}
	
	@SuppressWarnings("rawtypes")
	void printCollection(Collection collection) {
		if (collection == null || collection.isEmpty())
			return;
		boolean blank = false;
		for (Object x : collection) {
			if (blank) out.print(' '); else blank = true;
			out.print(x);
		}
		out.println();
	}
	
	/*************************************************************** 
	 * Utility
	 **************************************************************/
	static String memoryStatus() {
		return (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory() >> 20) + "/" + (Runtime.getRuntime().totalMemory() >> 20) + " MB";
	}
	
	static void checkMemory() {
		System.out.println(memoryStatus());
	}
	
	static long prevTimeStamp = Long.MIN_VALUE;
	
	static void updateTimer() {
		prevTimeStamp = System.currentTimeMillis();
	}
	
	static long elapsedTime() {
		return (System.currentTimeMillis() - prevTimeStamp);
	}
	
	static void checkTimer() {
		System.out.println(elapsedTime() + " ms");
	}
}
